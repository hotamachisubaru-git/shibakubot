.env.exampleを、.envにリネームしてください。
.envの中にある日本語で書かれた内容に従って書き換えてください。
動作しない場合はGitHubを参照してください
https://github.com/hotamachisubaru-git/shibakubot/